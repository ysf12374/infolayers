#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Mar 28 07:17:42 2021

@author: yousuf
"""
from geojson import Feature, FeatureCollection, Polygon

import h3
import geopandas as gp
from shapely.geometry import LineString, Point, LinearRing,Polygon
from math import sin, cos, sqrt, atan2, radians
import time
from tqdm import tqdm
import pandas as pd
from scipy import spatial
gpkg_path="/home/yousuf/Downloads/search_by_area/gadm36_ITA_gpkg/gadm36_ITA.gpkg"
gpkg_path="/home/yousuf/Downloads/search_by_area/gadm36_ITA_shp/gadm36_ITA_3.shp"
import mercantile
poly_lon=10.66175614705465
poly_lat=45.31389670416629
bounds = mercantile.bounds(poly_lon,poly_lat, 8)
minlon = bounds.west
minlat = bounds.south
maxlon = bounds.east
maxlat = bounds.north
polygon_check=Polygon([[minlon, minlat], [maxlon, minlat],
                 [maxlon, maxlat], [minlon, maxlat]])
import psycopg2

con = psycopg2.connect(database='infolayers', user='postgres',
    password='saamiya')
cur = con.cursor()
# Layer selected after sampling on GeoPackage viewer
#gdf = gp.read_file(gpkg_path, layer='gadm36_ARE_2')
shp = gp.GeoDataFrame.from_file(gpkg_path)
#h3_hexes = h3.polyfill(FeatureCollection(shp['geometry'][0]), 10)
#h3_hexes1 = h3.polyfill_geojson(Feature(shp['geometry'][0]), 10)

shp=shp.loc[(shp['GID_2'] == 'ITA.10.8_1')]
#shp=shp.loc[(shp['GID_3'] == 'ITA.10.8.72_1') | (shp['GID_3'] == 'ITA.1.1.15_1')]
sql=f"SELECT COUNT(case when points.tags->>'amenity'='bank' then points.id end) as banks, \
 COUNT(case when points.tags->>'amenity'='vending_machine' then points.id end) as vending_machine, \
 COUNT(case when points.tags->>'amenity'='recycling' then points.id end) as recycling, \
 COUNT(case when points.tags->>'amenity'='taxi' then points.id end) as taxi, \
AVG(COALESCE(CAST (properties->>'stars:norm' AS FLOAT), '0')) AS ratings \
 from points;"
sql='select * from points;'
s=pd.read_sql(sql,con=con)
shp_points = gp.read_postgis(sql,con=con, geom_col='geom')

poly_=str(shp['geometry'].values[0]).replace("POLYGON ((",'').replace("))",'').split(",")
#poly_=str(p[-1]).replace("POLYGON ((",'').replace("))",'').split(",")
stripped=lambda x : x.strip()
poly=list(map(stripped, poly_))
poly_f=[x.split(" ")[1]+" "+x.split(" ")[0] for x in poly]
poly_final=" ".join(poly_f)



all_hexagons=[]
all_features=[]
all_count=[]
check_hex=[1,2,3,4,5,6 ]
for a in tqdm(shp.itertuples(),total=len(shp)):
    try:
        hexs = h3.polyfill(a[-1].__geo_interface__, 8, geo_json_conformant = True)
        polygonise = lambda hex_id: Polygon(
                                        h3.h3_to_geo_boundary(
                                            hex_id, geo_json=True)
                                            )
        
        all_polys = gp.GeoSeries(list(map(polygonise, hexs)), \
                                              index=hexs, \
                                              crs="EPSG:4326" \
                                             )
#        [all_hexagons.append(l) for l in all_polys]
        #sql=f"SELECT *,\
        #ST_Contains(ST_GeomFromEWKT('SRID=4326; {str(all_polys[0])}'),\
        #            ST_GeomFromEWKT(col.geom)) \
        #FROM points As col;"
        for i in tqdm(all_polys,total=len(all_polys)):
            
            props={}
            sql=f"SELECT COUNT(case when points.tags->>'amenity'='bank' then points.id end) as banks, \
             COUNT(*) AS count, \
             COUNT(case when points.tags->>'amenity'='vending_machine' then points.id end) as vending_machine, \
             COUNT(case when points.tags->>'amenity'='recycling' then points.id end) as recycling, \
             COUNT(case when points.tags->>'amenity'='taxi' then points.id end) as taxi, \
             AVG(COALESCE(CAST (properties->>'stars:norm' AS FLOAT), '0')) AS ratings \
             from points where ST_Intersects(points.geom, 'SRID=4326;{str(i)}');"
#            sql=f"SELECT * \
#            from points where \
#            ST_Intersects(points.geom, 'SRID=4326;{str(i)}');"#where ST_Intersects(points.geom, 'SRID=4326;{str(i)}')
#            shp_ = gp.read_postgis(sql,con=con, geom_col='geom')
            shp_ = pd.read_sql(sql,con=con).fillna(0)
#            if sum(list(shp_.values[0]))>0:
#                break
            result = 1 - spatial.distance.cosine(check_hex, list(shp_.values[0]))
            if str(result)=="nan":
                result=0
            if len(shp_)>=1:
                all_features.append(result)
                all_hexagons.append(i)
                all_count.append(shp_.values[0][1])

    except:
        for k in a[-1]:
            hexs = h3.polyfill(k.__geo_interface__, 7, geo_json_conformant = True)
            polygonise = lambda hex_id: Polygon(
                                            h3.h3_to_geo_boundary(
                                                hex_id, geo_json=True)
                                                )
            
            all_polys = gp.GeoSeries(list(map(polygonise, hexs)), \
                                                  index=hexs, \
                                                  crs="EPSG:4326" \
                                                 )
            
            #sql=f"SELECT *,\
            #ST_Contains(ST_GeomFromEWKT('SRID=4326; {str(all_polys[0])}'),\
            #            ST_GeomFromEWKT(col.geom)) \
            #FROM points As col;"
            for i in tqdm(all_polys,total=len(all_polys)):
                sql=f"SELECT COUNT(case when points.tags->>'amenity'='bank' then points.id end) as banks, \
                 COUNT(*) AS count, \
                 COUNT(case when points.tags->>'amenity'='vending_machine' then points.id end) as vending_machine, \
                 COUNT(case when points.tags->>'amenity'='recycling' then points.id end) as recycling, \
                 COUNT(case when points.tags->>'amenity'='taxi' then points.id end) as taxi, \
                 AVG(COALESCE(CAST (properties->>'stars:norm' AS FLOAT), '0')) AS ratings \
                 from points where ST_Intersects(points.geom, 'SRID=4326;{str(i)}');"
#                sql=f"SELECT * from points where \
#                ST_Intersects(points.geom, 'SRID=4326;{str(i)}');"
#                shp_ = gp.read_postgis(sql,con=con, geom_col='geom')
                shp_ = pd.read_sql(sql,con=con).fillna(0)
#                if sum(list(shp_.values[0]))>0:
#                    break
                result = 1 - spatial.distance.cosine(check_hex, list(shp_.values[0]))
                if str(result)=="nan":
                    result=0
                if len(shp_)>=1:
                    all_features.append(result)
                    all_hexagons.append(i)
                    all_count.append(shp_.values[0][1])

cur.close()
con.close()
#FeatureCollection([Feature(
#        id = row["tilename"],
#        geometry = row["feat_geometry"],
#        properties = dict(
#            id = row["tilename"],
#            count=row.count,
#            rate = row.ratings,
#            color = colorScaleFader(row.ratings, mycolors)
#        )
#    ) for tilename,poly_feature in zip(all_hexagons,all_features,all_count)], name='re')

#import overpass
#api = overpass.API()
#result = api.get('node["amenity"](poly:"'+str(poly_final).strip()+'");', responseformat="geojson", verbosity="geom")
#features=result['features']
#
#for f in features:
#    crds=f['geometry']['coordinates']
#    lat=crds[1]
#    lon=crds[0]
#    src_id=f['id']
#    tags1=f['properties']
#    tags=str(tags1).replace("'",'"')
#    sql=f"""INSERT INTO points (src_id, source_name, geom, source_id, \
#    tags,crds) values \
#    ('570','osm',ST_SetSRID( ST_Point( {lon}, {lat}), 4326),'{src_id}',\
#    '{tags}','{str(crds)}') ON CONFLICT (source_id) DO UPDATE SET tags='{tags}'; """
#    break
#



import pyproj
geod = pyproj.Geod(ellps='WGS84')
polys=[(float(x.split(" ")[1]),float(x.split(" ")[0])) for x in poly_f]
polys=polys[:-1]
# create example polygon
poly = Polygon(polys)

# get minimum bounding box around polygon
box = poly.minimum_rotated_rectangle

# get coordinates of polygon vertices
x, y = box.exterior.coords.xy
point1=Point(x[0], y[0])
point2=Point(x[1], y[1])
point3=Point(x[1], y[1])
point4=Point(x[2], y[2])

# get length of bounding box edges
#edge_length = (Point(x[0], y[0]).distance(Point(x[1], y[1])), Point(x[1], y[1]).distance(Point(x[2], y[2])))
edge_length = (geod.inv(point1.x, point1.y, point2.x, point2.y)[-1], geod.inv(point3.x, point3.y, point4.x, point4.y)[-1])

# get length of polygon as the longest edge of the bounding box
length = max(edge_length)

# get width of polygon as the shortest edge of the bounding box
width = min(edge_length)






