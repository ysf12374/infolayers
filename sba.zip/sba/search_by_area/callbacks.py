# -*- coding: utf-8 -*-

from py4web import Field
from ..common import db

from ..planetclient.callbacks import _geomdbset, _get_buffered_bounds

import h3
import mercantile as mt
from geojson import Feature, FeatureCollection, Polygon
from pyproj import Geod
from shapely.geometry import Polygon as Polygon_
from shapely.geometry import Point as Point_
import math
import geojson
from itertools import groupby, chain
import scipy
from geomet import wkt
import mercantile
from geojson2vt.geojson2vt import geojson2vt
import geopandas as gp

from kilimanjaro.color.loader import colors
from kilimanjaro.color.fader import colorScaleFader, parse

from ..planetstore.tools.tilesets import tile_by_dim, zoom2dims
from ..planetstore.setup.postgresql import __replace_view

# from ..planetclient.pbftools import geom2tile
from ..planetstore.populate.optutils.base import Turbo
from ..planetstore.populate.populate import osm2db, db

from bs4 import BeautifulSoup
import requests as rqs
import psycopg2
from scipy import spatial
import pandas as pd
from tqdm import tqdm

mycolors = colors["colortona"]["Hold"]["5"]

def hex2poly(hex):
    outline = list(map(lambda latlon: latlon, h3.h3_set_to_multi_polygon([hex], geo_json=True)[0][0]))
    return Polygon([outline])

def _select_points(minlon, minlat, maxlon, maxlat,
    source_name='__GENERIC__', tags=[], fields=[]
):
    """ """

    basedbset = _geomdbset(db.points, minlon, minlat, maxlon, maxlat,
        source_name=source_name, tags=tags
    )
    # dbset = basedbset((db.points.id==db.restate.info_id))
    dbset = basedbset((db.points.source_name=='tripadvisor') & ("(points.properties->>'amenity'='hotel' or points.properties->>'amenity'='restaurant')") )

    result = dbset.select(
        db.points.id,
        db.points.src_id,
        db.points.geom,
        *fields
    )
    return result

def fetch(minlon, minlat, maxlon, maxlat,
    source_name='__GENERIC__', tags=[],
    zoom=18, tile=False
):
    """
    """

    left, bottom, right, top, resolution = _get_buffered_bounds(
        minlon, minlat, maxlon, maxlat,
        zoom = zoom, classic = tile
    )

    # price = "(points.properties->>'price:€')::integer"
    # surface = "(points.properties->>'surface:m²')::integer"
    # address = "(points.properties->>'address')"
    ratings="COALESCE(CAST (points.properties->>'stars:norm' AS FLOAT), '0') AS ratings"

    result = _select_points(left, bottom, right, top,
        source_name=source_name, tags=tags,
        fields = [ratings]
    )

    features = [Feature(
        id = row.points.hashid,
        geometry = row.points.feat_geometry,
        properties = dict(
            id = row.points.hashid,
            rate = row.ratings,
        )
    ) for row in result]

    return FeatureCollection(features)

def fetch_a_tile(lon, lat, mindist=155, classic=False, source_name='__GENERIC__'):
    """
    lon, lat @float : A point cooridnates;
    mindist @integer/float : The tile will be dimensioned with this dinstance as minimal;
    classic @boolean : Whether to use classic square tiles or Uber H3 hexagonal ones;
    source_name @string : Source name filter.
    """

    tile = tile_by_dim(lon, lat, bdim=mindist, asc=False, classic=classic)
    if classic:
        tilename = '/'.join(map(str, tile))
        polygon_ = mt.feature(tile)['geometry']
    else:
        tilename = tile
        outline = list(map(lambda latlon: latlon, h3.h3_set_to_multi_polygon([tile], geo_json=True)[0][0]))
        polygon_ = Polygon([outline])

    polygon = geojson.dumps(polygon_) 

    basequery = (db.points.source_name==source_name)
    basequery &= (db.points.id==db.restate.info_id)
    basequery &= f"ST_Intersects(points.geom, ST_SetSRID(ST_GeomFromGeoJSON('{polygon}'), 4326))"

    price = "(points.properties->>'price:€')::integer"
    surface = "(points.properties->>'surface:m²')::integer"

    mrate = "PERCENTILE_CONT(0.5) WITHIN GROUP(ORDER BY restate.stdup) as mrate"
    pricemax = f"MAX({price}) as pricemax"
    pricemin = f"MIN({price}) as pricemin"
    count = f"COUNT(restate.id) as count"
    upricemax = f"MAX(({price}/{surface})::integer) as upricemax"
    upricemin = f"MIN(({price}/{surface})::integer) as upricemin"

    row = db(basequery).select(
        db.restate.stdup.avg().with_alias("rate"),
        mrate,
        pricemax,
        pricemin,
        count,
        upricemax,
        upricemin
    ).first()

    return Feature(
        id = tilename,
        geometry = polygon_,
        properties = dict(
            id = tilename,
            rate = row.rate,
            mrate = row[mrate],
            pricemax = row[pricemax],
            pricemin = row[pricemin],
            count = row[count],
            upricemax = row[upricemax],
            upricemin = row[upricemin]
        )
    )

def fetchtiled_(minlon, minlat, maxlon, maxlat, zoom=18, classic=False,
    source_name='__GENERIC__', tags=[]
):
    """
    minlon, minlat, maxlon, maxlat @float : Bbox limits;
    zoon @integer : Square tile zoom level or hexagonal tile resolution;
    classic @boolean : Whether to use classic square tiles or Uber H3 hexagonal ones;
    source_name @string : Source name filter;
    tags @dict[] : Tags to be used as filter.

    Returns: Rows
    """

    left, bottom, right, top, resolution = _get_buffered_bounds(
        minlon, minlat, maxlon, maxlat,
        zoom = zoom, classic = classic
    )

    price = "(points.properties->>'price:€')::integer"
    surface = "(points.properties->>'surface:m²')::integer"
    if classic:
        tile_ = f"T_tile(points.geom, {resolution})"
        tilename_ = f"T_tilename({tile_})"
        # polygon_ = f"T_bounds({tile_})"
        get_poly_method = "T_bounds(buzz.tile)"

        # tilename_ = f"tilename(points.geom, {resolution})"
        # polygon_ = f"bounds_for_tile_indices(ST_Y(tile_indices_for_lonlat(points.geom, {resolution})), ST_X(tile_indices_for_lonlat(points.geom, {resolution})), {resolution})"
    else:
        tile_ = f"h3_geo_to_h3index(points.geom, {resolution})"
        tilename_ = tile_
        # polygon_ = f"h3_h3index_to_geoboundary(h3_geo_to_h3index(points.geom, {resolution}))"
        get_poly_method = "h3_h3index_to_geoboundary(buzz.tile)"

    # geom_ = f"ST_AsGeoJSON({polygon_})"
    basedbset = _geomdbset(db.points, left, bottom, right, top,
        source_name=source_name, tags=tags
    )
    s=f"ST_Contains(ST_GEOMFROMTEXT('POLYGON({minlon} {minlat}, {maxlon} {minlat}, {maxlon} {maxlat}, {minlon} {maxlat}, {minlon} {minlat}))'), points.geom)"

    dbset = basedbset(("(points.tags->>'highway'='bus_stop' or points.tags->>'amenity'='parking' or points.tags->>'amenity'='bus_station')"))

    tile = f"{tile_} as tile"
    tilename = f"{tilename_} as tilename"
    # geom = f"(array_agg({geom_}))[1] as geom"

    # ratings="AVG(COALESCE(CAST (properties->>'stars:norm' AS FLOAT), '0')) AS ratings"
    count="COUNT(*) AS count"
    ratings="cast(COUNT(source_name) as decimal) / 3 AS ratings"
    query = dbset._select(
        db.points.id.min().with_alias('id'),
        tile,
        tilename,
        count,
        ratings,
        orderby = "tilename",
        groupby = "tilename, tile"
    )
    __replace_view('buzz', f"SELECT {get_poly_method} as geom, * FROM ({query[:-1]}) as buzz")

    db.define_table('buzz',
        Field('geom', 'geometry()'),
        Field('tilename'),
        Field('ratings', 'double'),
        Field('count', 'double'),
        Field.Virtual('feat_geometry', lambda row: wkt.loads(row['buzz'].geom)),
        migrate = False,
        redefine = True
    )

    result = db(db.buzz.id>0).select()
    
    db.rollback()
    # import pdb; pdb.set_trace()
    return result

def fetchtiled(names='Lombardia, Milano;',lat=45.31389670416629,lon=10.66175614705465,
    source_name='osm', tags=[]
):
    """
    minlon, minlat, maxlon, maxlat @float : Bbox limits;
    zoon @integer : Square tile zoom level or hexagonal tile resolution;
    classic @boolean : Whether to use classic square tiles or Uber H3 hexagonal ones;
    source_name @string : Source name filter;
    tags @dict[] : Tags to be used as filter.

    Returns: Geojson FeatureCollection of the selected points grouped by tiles.
    """

    con = psycopg2.connect(database='infolayers', user='postgres',
        password='saamiya')
    cur = con.cursor()
    poly_lon=10.66175614705465
    poly_lat=45.31389670416629
    turbo = Turbo()

    qconditions = [{
        "query": [[{"k": "highway","v":"bus_stop"}],
        [{"k": "public_transport","v":"platform"}],
        [{"k": "amenity","v":"parking"}],
        [{"k": "amenity","v":"parking_space"}],
        [{"k": "amenity","v":"fuel"}],
        [{"k": "amenity","v":"bus_station"}]],
        "distance": 600
    }]

    query = turbo.build_query(
        turbo.optimize_centralized_query(poly_lon, poly_lat,
            qconditions,
            # buffer=buffer
        ),
        # gtypes=gtypes
    )

    data = turbo(query)
    osm2db(data.nodes, data.ways, data.relations,copy=False)
    db.commit()
    bounds = mercantile.bounds(poly_lon,poly_lat, 8)
    minlon = bounds.west
    minlat = bounds.south
    maxlon = bounds.east
    maxlat = bounds.north
    polygon_check=Polygon_([[minlon, minlat], [maxlon, minlat],
                     [maxlon, maxlat], [minlon, maxlat]])
    sql=f"SELECT COUNT(case when points.tags->>'amenity'='bank' then points.id end) as banks, \
     COUNT(*) AS count, \
     COUNT(case when points.tags->>'amenity'='vending_machine' then points.id end) as vending_machine, \
     COUNT(case when points.tags->>'amenity'='recycling' then points.id end) as recycling, \
     COUNT(case when points.tags->>'amenity'='taxi' then points.id end) as taxi, \
     AVG(COALESCE(CAST (properties->>'stars:norm' AS FLOAT), '0')) AS ratings \
     from points where ST_Intersects(points.geom, 'SRID=4326;{str(polygon_check)}');"
    shp_check = pd.read_sql(sql,con=con).fillna(0)
    check_hex = list(shp_check.values[0])
    check_hex= [1,2,3,4,5,6]
    names='Abruzzo, Chieti, Borrello;Lombardia, Sondrio, Sondrio'
    names='Abruzzo, Chieti, Borrello;'
    names='Lombardia, Milano;'

    names=names.split(";")
    names=[x for x in names if x!='' or x]
    gpkg_path="/home/yousuf/Downloads/search_by_area/gadm36_ITA_shp/gadm36_ITA_3.shp"
    shp = gp.GeoDataFrame.from_file(gpkg_path)
    all_hexagons=[]
    all_features=[]
    all_count=[]
    for name in names:
        shp=shp.loc[(shp['NAME_1'] == name.split(",")[0].strip()) &\
         (shp['NAME_2'] == name.split(",")[1].strip())]
        geod = Geod(ellps='WGS84')
        poly_=str(shp['geometry'].values[0]).replace("POLYGON ((",'').replace("))",'').split(",")
        stripped=lambda x : x.strip()
        poly=list(map(stripped, poly_))
        poly_f=[x.split(" ")[1]+" "+x.split(" ")[0] for x in poly]
        poly_final=" ".join(poly_f)
        polys=[(float(x.split(" ")[1]),float(x.split(" ")[0])) for x in poly_f]
        polys=polys[:-1]

        # create example polygon
        poly = Polygon_(polys)

        # get minimum bounding box around polygon
        box = poly.minimum_rotated_rectangle
        polygon_centroid = box.centroid
        poly_lat=polygon_centroid.y
        poly_lon=polygon_centroid.x
        # get coordinates of polygon vertices
        x, y = box.exterior.coords.xy
        point1=Point_(x[0], y[0])
        point2=Point_(x[1], y[1])
        point3=Point_(x[1], y[1])
        point4=Point_(x[2], y[2])

        # get length of bounding box edges
        #edge_length = (Point(x[0], y[0]).distance(Point(x[1], y[1])), Point(x[1], y[1]).distance(Point(x[2], y[2])))
        edge_length = (geod.inv(point1.x, point1.y, point2.x, point2.y)[-1], geod.inv(point3.x, point3.y, point4.x, point4.y)[-1])

        # get length of polygon as the longest edge of the bounding box
        length = max(edge_length)
        radius = int(length/2)
        turbo = Turbo()

        qconditions = [{
            "query": [[{"k": "highway","v":"bus_stop"}],
            [{"k": "public_transport","v":"platform"}],
            [{"k": "amenity","v":"parking"}],
            [{"k": "amenity","v":"parking_space"}],
            [{"k": "amenity","v":"fuel"}],
            [{"k": "amenity","v":"bus_station"}]],
            "distance": radius+600
        }]

        query = turbo.build_query(
            turbo.optimize_centralized_query(poly_lon, poly_lat,
                qconditions,
                # buffer=buffer
            ),
            # gtypes=gtypes
        )

        data = turbo(query)
        osm2db(data.nodes, data.ways, data.relations,copy=False)
        db.commit()
        for a in tqdm(shp.itertuples(),total=len(shp)):
            try:
                hexs = h3.polyfill(a[-1].__geo_interface__, 8, geo_json_conformant = True)
                polygonise = lambda hex_id: Polygon_(
                                                h3.h3_to_geo_boundary(
                                                    hex_id, geo_json=True)
                                                    )
                
                all_polys = gp.GeoSeries(list(map(polygonise, hexs)), \
                                                      index=hexs, \
                                                      crs="EPSG:4326" \
                                                     )
        #        [all_hexagons.append(l) for l in all_polys]
                #sql=f"SELECT *,\
                #ST_Contains(ST_GeomFromEWKT('SRID=4326; {str(all_polys[0])}'),\
                #            ST_GeomFromEWKT(col.geom)) \
                #FROM points As col;"
                for i in tqdm(all_polys,total=len(all_polys)):
                    
                    props={}
                    sql=f"SELECT COUNT(case when points.tags->>'amenity'='bank' then points.id end) as banks, \
                     COUNT(*) AS count, \
                     COUNT(case when points.tags->>'amenity'='vending_machine' then points.id end) as vending_machine, \
                     COUNT(case when points.tags->>'amenity'='recycling' then points.id end) as recycling, \
                     COUNT(case when points.tags->>'amenity'='taxi' then points.id end) as taxi, \
                     AVG(COALESCE(CAST (properties->>'stars:norm' AS FLOAT), '0')) AS ratings \
                     from points where ST_Intersects(points.geom, 'SRID=4326;{str(i)}');"
        #            sql=f"SELECT * \
        #            from points where \
        #            ST_Intersects(points.geom, 'SRID=4326;{str(i)}');"#where ST_Intersects(points.geom, 'SRID=4326;{str(i)}')
        #            shp_ = gp.read_postgis(sql,con=con, geom_col='geom')
                    shp_ = pd.read_sql(sql,con=con).fillna(0)
        #            if sum(list(shp_.values[0]))>0:
        #                break
                    result = 1 - spatial.distance.cosine(check_hex, list(shp_.values[0]))
                    if str(result)=="nan":
                        result=0
                    if len(shp_)>=1:
                        all_features.append(result)
                        all_hexagons.append(i)
                        all_count.append(shp_.values[0][1])

            except:
                for k in a[-1]:
                    hexs = h3.polyfill(k.__geo_interface__, 7, geo_json_conformant = True)
                    polygonise = lambda hex_id: Polygon_(
                                                    h3.h3_to_geo_boundary(
                                                        hex_id, geo_json=True)
                                                        )
                    
                    all_polys = gp.GeoSeries(list(map(polygonise, hexs)), \
                                                          index=hexs, \
                                                          crs="EPSG:4326" \
                                                         )
                    
                    #sql=f"SELECT *,\
                    #ST_Contains(ST_GeomFromEWKT('SRID=4326; {str(all_polys[0])}'),\
                    #            ST_GeomFromEWKT(col.geom)) \
                    #FROM points As col;"
                    for i in tqdm(all_polys,total=len(all_polys)):
                        sql=f"SELECT COUNT(case when points.tags->>'amenity'='bank' then points.id end) as banks, \
                         COUNT(*) AS count, \
                         COUNT(case when points.tags->>'amenity'='vending_machine' then points.id end) as vending_machine, \
                         COUNT(case when points.tags->>'amenity'='recycling' then points.id end) as recycling, \
                         COUNT(case when points.tags->>'amenity'='taxi' then points.id end) as taxi, \
                         AVG(COALESCE(CAST (properties->>'stars:norm' AS FLOAT), '0')) AS ratings \
                         from points where ST_Intersects(points.geom, 'SRID=4326;{str(i)}');"
        #                sql=f"SELECT * from points where \
        #                ST_Intersects(points.geom, 'SRID=4326;{str(i)}');"
        #                shp_ = gp.read_postgis(sql,con=con, geom_col='geom')
                        shp_ = pd.read_sql(sql,con=con).fillna(0)
        #                if sum(list(shp_.values[0]))>0:
        #                    break
                        result = 1 - spatial.distance.cosine(check_hex, list(shp_.values[0]))
                        if str(result)=="nan":
                            result=0
                        if len(shp_)>=1:
                            all_features.append(result)
                            all_hexagons.append(i)
                            all_count.append(shp_.values[0][1])

    return  FeatureCollection([Feature(
        id = tilename,
        geometry = poly_feature[0],
        properties = dict(
            id = tilename,
            count=poly_feature[2],
            rate = poly_feature[1],
            color = colorScaleFader(poly_feature[1], mycolors)
        )
    ) for tilename,poly_feature in enumerate(zip(all_hexagons,all_features,all_count))], name='re')



def vtile(x, y, z=18, resolution=18, classic=True, source_name='__GENERIC__', tags=[]):
    """ """

    bounds = mercantile.bounds(x, y, z)

    result = fetchtiled_(
        minlon = bounds.west,
        minlat = bounds.south,
        maxlon = bounds.east,
        maxlat = bounds.north,
        zoom = resolution,
        classic = classic,
        source_name = source_name,
        tags = tags
    )

    return dict(
        name = 'mytiles',
        # extent = 4096,
        # version = 2,
        features = [dict(
            id = row["tilename"],
            type = 3,
            geometry = geom2tile(x, y, z, row.feat_geometry),
            properties = dict(
                id = row["tilename"],
                rate = row.rate,
                mrate = row["mrate"],
                pricemax = row["pricemax"],
                pricemin = row["pricemin"],
                count = row["count"],
                upricemax = row["upricemax"],
                upricemin = row["upricemin"],
                color = colorScaleFader(row.rate, mycolors)
            )
        ) for nn,row in enumerate(result)]
    )

def fetch_and_tile(minlon, minlat, maxlon, maxlat, zoom=18, classic=False,
    source_name='__GENERIC__', tags=[]
):
    """
    minlon, minlat, maxlon, maxlat @float : Bbox limits;
    zoon @integer : Square tile zoom level or hexagonal tile resolution;
    classic @boolean : Whether to use classic square tiles or Uber H3 hexagonal ones;
    source_name @string : Source name filter;
    tags @dict[] : Tags to be used as filter.

    Returns: Geojson FeatureCollection of the selected points grouped by tiles.
    """

    left, bottom, right, top, resolution = _get_buffered_bounds(
        minlon, minlat, maxlon, maxlat,
        zoom = zoom, classic = classic
    )

    price = "(points.properties->>'price:€')::integer"
    surface = "(points.properties->>'surface:m²')::integer"

    result = _select_points(left, bottom, right, top,
        source_name=source_name, tags=tags,
        fields = [price, surface]
    )

    sgf = lambda row: row.points.tile(zoom=resolution, classic=tile)
    data = sorted(result, key=sgf)
    grouped = groupby(data, sgf)

    def props(nfo_):
        nfo = list(nfo_)
        return dict(
            rate = scipy.mean(list(map(lambda ff: ff['rate'], nfo))),
            mrate = scipy.median(list(map(lambda ff: ff['rate'], nfo))),
            pricemax = max(map(lambda ff: ff['_extra'][price], nfo)),
            pricemin = min(map(lambda ff: ff['_extra'][price], nfo)),
            upricemax = max(map(lambda ff: ff['_extra'][price]//ff['_extra'][surface], nfo)),
            upricemin = min(map(lambda ff: ff['_extra'][price]//ff['_extra'][surface], nfo)),
            count = len(nfo)
        )

    if tile:
        features = [mt.feature(tile_, props=props(nfo)) for tile_, nfo in grouped]
    else:
        features = [Feature(
            id = tile_,
            geometry = hex2poly(tile_),
            properties = props(nfo)
        ) for tile_, nfo in grouped]

    return FeatureCollection(features)

def arc_fetch(lat,lon,source_name='osm'):
    result=db.executesql(f"select * from points where source_name='osm' \
     and (points.tags->>'highway'='bus_stop'\
     or points.tags->>'public_transport'='platform'\
      or points.tags->>'amenity'='parking'\
      or points.tags->>'amenity'='parking_space'\
      or points.tags->>'amenity'='fuel'\
      or points.tags->>'amenity'='bus_station'\
      ) \
     and ST_DistanceSphere(geom,ST_MakePoint({lon},{lat}))<=8*1609.34;")
    if not result or len(result)<1:
        turbo = Turbo()

        qconditions = [{
            "query": [[{"k": "highway","v":"bus_stop"}],
            [{"k": "public_transport","v":"platform"}],
            [{"k": "amenity","v":"parking"}],
            [{"k": "amenity","v":"parking_space"}],
            [{"k": "amenity","v":"fuel"}],
            [{"k": "amenity","v":"bus_station"}]],
            "distance": 500
        }]

        query = turbo.build_query(
            turbo.optimize_centralized_query(lon, lat,
                qconditions,
                # buffer=buffer
            ),
            # gtypes=gtypes
        )
        data = turbo(query)

        osm2db(data.nodes, data.ways, data.relations,copy=False)
        db.commit()
    result=db.executesql(f"select * from points where source_name='osm' \
     and (points.tags->>'highway'='bus_stop'\
     or points.tags->>'public_transport'='platform'\
      or points.tags->>'amenity'='parking'\
      or points.tags->>'amenity'='parking_space'\
      or points.tags->>'amenity'='fuel'\
      or points.tags->>'amenity'='bus_station'\
      ) \
     and ST_DistanceSphere(geom,ST_MakePoint({lon},{lat}))<=8*1609.34;")
    # (1315, 570, 'osm', '0101000020E61000007CB94F8E0274224054FEB5BC722D4640',
    #  '765553419',
    #   {'amenity': 'kindergarten', 'name': 'Scuola Materna Villa Lina'}, 
    #   None, [9.226582, 44.355064], 1315)
    try:
        coords=[[x[7][1],x[7][0]] for x in result]
    except:
        coords=[]
    results={"coordinates":coords}
    return results


def arc_fetch_parking(lat,lon,source_name='osm'):
    result=db.executesql(f"select * from points where source_name='osm' \
     and (points.tags->>'amenity'='parking'\
      or points.tags->>'amenity'='parking_space'\
      or points.tags->>'amenity'='fuel'\
      ) \
     and ST_DistanceSphere(geom,ST_MakePoint({lon},{lat}))<=8*1609.34;")
    if not result or len(result)<1:
        turbo = Turbo()

        qconditions = [{
            "query": [
            [{"k": "amenity","v":"parking"}],
            [{"k": "amenity","v":"fuel"}],
            [{"k": "amenity","v":"parking_space"}]
            ],
            "distance": 600
        }]

        query = turbo.build_query(
            turbo.optimize_centralized_query(lon, lat,
                qconditions,
                # buffer=buffer
            ),
            # gtypes=gtypes
        )
        data = turbo(query)

        osm2db(data.nodes, data.ways, data.relations,copy=False)
        db.commit()
    result=db.executesql(f"select * from points where source_name='osm' \
     and (points.tags->>'amenity'='parking'\
      or points.tags->>'amenity'='parking_space'\
      or points.tags->>'amenity'='fuel'\
      ) \
     and ST_DistanceSphere(geom,ST_MakePoint({lon},{lat}))<=8*1609.34;")
    # (1315, 570, 'osm', '0101000020E61000007CB94F8E0274224054FEB5BC722D4640',
    #  '765553419',
    #   {'amenity': 'kindergarten', 'name': 'Scuola Materna Villa Lina'}, 
    #   None, [9.226582, 44.355064], 1315)
    try:
        coords=[[x[7][1],x[7][0]] for x in result]
    except:
        coords=[]
    results={"coordinates":coords}
    return results

def arc_fetch_groceries(lat,lon,source_name='osm'):
    result=db.executesql(f"select * from points where source_name='osm' \
     and (points.tags->>'shop'='convenience'\
     or points.tags->>'shop'='supermarket'\
      or points.tags->>'shop'='bakery'\
      or points.tags->>'shop'='butcher'\
      or points.tags->>'shop'='alcohol'\
      or points.tags->>'shop'='mall'\
      or points.tags->>'shop'='variety_store'\
      or points.tags->>'shop'='department_store'\
      or points.tags->>'shop'='confectionery'\
      or points.tags->>'shop'='kiosk'\
      ) \
     and ST_DistanceSphere(geom,ST_MakePoint({lon},{lat}))<=8*1609.34;")
    if not result or len(result)<1:
        turbo = Turbo()

        qconditions = [{
            "query": [
            [{"k": "shop","v":"convenience"}],
            [{"k": "shop","v":"supermarket"}],
            [{"k": "shop","v":"bakery"}],
            [{"k": "shop","v":"butcher"}],
            [{"k": "shop","v":"alcohol"}],
            [{"k": "shop","v":"mall"}],
            [{"k": "shop","v":"variety_store"}],
            [{"k": "shop","v":"department_store"}],
            [{"k": "shop","v":"confectionery"}],
            [{"k": "shop","v":"kiosk"}]
            ],
            "distance": 400
        }]

        query = turbo.build_query(
            turbo.optimize_centralized_query(lon, lat,
                qconditions,
                # buffer=buffer
            ),
            # gtypes=gtypes
        )
        data = turbo(query)

        osm2db(data.nodes, data.ways, data.relations,copy=False)
        db.commit()
    result=db.executesql(f"select * from points where source_name='osm' \
     and (points.tags->>'shop'='convenience'\
     or points.tags->>'shop'='supermarket'\
      or points.tags->>'shop'='bakery'\
      or points.tags->>'shop'='butcher'\
      or points.tags->>'shop'='alcohol'\
      or points.tags->>'shop'='mall'\
      or points.tags->>'shop'='variety_store'\
      or points.tags->>'shop'='department_store'\
      or points.tags->>'shop'='confectionery'\
      or points.tags->>'shop'='kiosk'\
      ) \
     and ST_DistanceSphere(geom,ST_MakePoint({lon},{lat}))<=8*1609.34;")
    # (1315, 570, 'osm', '0101000020E61000007CB94F8E0274224054FEB5BC722D4640',
    #  '765553419',
    #   {'amenity': 'kindergarten', 'name': 'Scuola Materna Villa Lina'}, 
    #   None, [9.226582, 44.355064], 1315)
    try:
        coords=[[x[7][1],x[7][0]] for x in result]
    except:
        coords=[]
    results={"coordinates":coords}
    return results

def arc_fetch_shop(lat,lon,source_name='osm'):
    result=db.executesql(f"select * from points where source_name='osm' \
     and (points.tags->>'shop'='electronics'\
     or points.tags->>'shop'='florist'\
      or points.tags->>'shop'='mobile_phone'\
      or points.tags->>'shop'='furniture'\
      or points.tags->>'shop'='hardware'\
      or points.tags->>'shop'='shoes'\
      or points.tags->>'shop'='mall'\
      or points.tags->>'shop'='jewelry'\
      or points.tags->>'shop'='optician'\
      or points.tags->>'shop'='gift'\
      or points.tags->>'shop'='books'\
      or points.tags->>'shop'='sports'\
      or points.tags->>'shop'='laundry'\
      or points.tags->>'shop'='stationery'\
      or points.tags->>'shop'='chemist'\
      or points.tags->>'shop'='pet'\
      or points.tags->>'shop'='clothes'\
      or points.tags->>'shop'='computer'\
      ) \
     and ST_DistanceSphere(geom,ST_MakePoint({lon},{lat}))<=8*1609.34;")
    if not result or len(result)<1:
        turbo = Turbo()

        qconditions = [{
            "query": [
            [{"k": "shop","v":"electronics"}],
            [{"k": "shop","v":"florist"}],
            [{"k": "shop","v":"mobile_phone"}],
            [{"k": "shop","v":"furniture"}],
            [{"k": "shop","v":"hardware"}],
            [{"k": "shop","v":"shoes"}],
            [{"k": "shop","v":"mall"}],
            [{"k": "shop","v":"jewelry"}],
            [{"k": "shop","v":"optician"}],
            [{"k": "shop","v":"gift"}],
            [{"k": "shop","v":"books"}],
            [{"k": "shop","v":"sports"}],
            [{"k": "shop","v":"laundry"}],
            [{"k": "shop","v":"stationery"}],
            [{"k": "shop","v":"chemist"}],
            [{"k": "shop","v":"pet"}],
            [{"k": "shop","v":"clothes"}],
            [{"k": "shop","v":"computer"}]
            ],
            "distance": 600
        }]

        query = turbo.build_query(
            turbo.optimize_centralized_query(lon, lat,
                qconditions,
                # buffer=buffer
            ),
            # gtypes=gtypes
        )
        data = turbo(query)

        osm2db(data.nodes, data.ways, data.relations,copy=False)
        db.commit()
    result=db.executesql(f"select * from points where source_name='osm' \
     and (points.tags->>'shop'='electronics'\
     or points.tags->>'shop'='florist'\
      or points.tags->>'shop'='mobile_phone'\
      or points.tags->>'shop'='furniture'\
      or points.tags->>'shop'='hardware'\
      or points.tags->>'shop'='shoes'\
      or points.tags->>'shop'='mall'\
      or points.tags->>'shop'='jewelry'\
      or points.tags->>'shop'='optician'\
      or points.tags->>'shop'='gift'\
      or points.tags->>'shop'='books'\
      or points.tags->>'shop'='sports'\
      or points.tags->>'shop'='laundry'\
      or points.tags->>'shop'='stationery'\
      or points.tags->>'shop'='chemist'\
      or points.tags->>'shop'='pet'\
      or points.tags->>'shop'='clothes'\
      or points.tags->>'shop'='computer'\
      ) \
     and ST_DistanceSphere(geom,ST_MakePoint({lon},{lat}))<=8*1609.34;")
    # (1315, 570, 'osm', '0101000020E61000007CB94F8E0274224054FEB5BC722D4640',
    #  '765553419',
    #   {'amenity': 'kindergarten', 'name': 'Scuola Materna Villa Lina'}, 
    #   None, [9.226582, 44.355064], 1315)
    try:
        coords=[[x[7][1],x[7][0]] for x in result]
    except:
        coords=[]
    results={"coordinates":coords}
    return results



def fetchtiled_heatmap(minlon, minlat, maxlon, maxlat, zoom=18, classic=False,
    source_name='__GENERIC__', tags=[]
):
    """
    minlon, minlat, maxlon, maxlat @float : Bbox limits;
    zoon @integer : Square tile zoom level or hexagonal tile resolution;
    classic @boolean : Whether to use classic square tiles or Uber H3 hexagonal ones;
    source_name @string : Source name filter;
    tags @dict[] : Tags to be used as filter.

    Returns: Rows
    """
    left, bottom, right, top, resolution = _get_buffered_bounds(
        minlon, minlat, maxlon, maxlat,
        zoom = zoom, classic = classic
    )

    polygon=Polygon_([[left, bottom], [right, bottom],
                     [right, top], [left, top]])
    geod = Geod(ellps="WGS84")
    area = abs(geod.geometry_area_perimeter(polygon)[0])
    polygon_centroid = polygon.centroid
    poly_lat=polygon_centroid.y
    poly_lon=polygon_centroid.x
    turbo = Turbo()

    qconditions = [{
        "query": [[{"k": "highway","v":"bus_stop"}],
        [{"k": "public_transport","v":"platform"}],
        [{"k": "amenity","v":"parking"}],
        [{"k": "amenity","v":"parking_space"}],
        [{"k": "amenity","v":"fuel"}],
        [{"k": "amenity","v":"bus_station"}]],
        "distance": 800
    }]

    query = turbo.build_query(
        turbo.optimize_centralized_query(poly_lon, poly_lat,
            qconditions,
            # buffer=buffer
        ),
        # gtypes=gtypes
    )
    data = turbo(query)

    osm2db(data.nodes, data.ways, data.relations,copy=False)
    db.commit()

    # geom_ = f"ST_AsGeoJSON({polygon_})"
    basedbset = _geomdbset(db.points, left, bottom, right, top,
        source_name=source_name, tags=tags
    )
    s=f"ST_Contains(ST_GEOMFROMTEXT('POLYGON({minlon} {minlat}, {maxlon} {minlat}, {maxlon} {maxlat}, {minlon} {maxlat}, {minlon} {minlat}))'), points.geom)"

    dbset = basedbset(("(points.tags->>'highway'='bus_stop' or points.tags->>'amenity'='parking' or points.tags->>'amenity'='bus_station')"))
    lat="ST_Y(geom) as lat"
    lon="ST_X(geom) as lon"
    query= dbset._select(
        lat,
        lon
        )
    results=db.executesql(query)
    features=[[x[0],x[1],1.0] for x in results]
    result={"coordinates":features}
    return result




if __name__ == '__main__':
    minlon, minlat = 9.2250188128,44.3481485822#9.2242306064, 44.3481485822
    maxlon, maxlat = 9.2346577051,44.3537697214#9.2354459115, 44.3537697214
    minlon, minlat,maxlon, maxlat = 9.1847091805,45.4660794509,9.1875362288,45.4675203684
    
    minlon, minlat,maxlon, maxlat = 9.156675338745117,45.44700505065907,9.207830429077148,45.473734673049165
    fc = fetchtiled()
    # fc=arc_fetch(44.351,9.2344)
    # fc = fetchtiled_heatmap(minlon, minlat, maxlon, maxlat, zoom=18, classic=False, source_name='osm')
    # fc = fetch(minlon, minlat, maxlon, maxlat, zoom=18, tile=False, source_name='tripadvisor')
    import pdb; pdb.set_trace()
